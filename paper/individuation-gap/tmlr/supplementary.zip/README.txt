Supplementary material (anonymized).
proofs/IndividuationGap.lean  - Lean 4 / Mathlib proofs of Theorems 1-3 (the gap).
proofs/FusionMath.lean        - Lean 4 / Mathlib proof of the inverse-variance fusion lemma.
code/make_figures.py          - regenerates all figures.
code/prob_falsification.py    - Bayesian enrollment simulation (Section 4 / Appendix B).
